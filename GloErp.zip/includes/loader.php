<div id="loader-wrapper">
    <div class="loader">
        <img src="/GloERP/images/glo-logo.png" alt="glo-erp logo">
    </div>
</div>

