<section id="contact">
    
    <div class="contact">
        <h4>
            Do you have any questions or inquiries? Feel free to reach out to us!
        </h4>
        <div class="demo-contact-cont">

            <a class="demo-btn" href="../demo.php"><span class="far fa-bell"></span> &nbsp;Request a Demo</a>


            <a class="cont-btn" href="../contact.php"><span class="fas fa-phone-volume"></span> &nbsp;Contact Us</a>


        </div>
    </div>

</section>