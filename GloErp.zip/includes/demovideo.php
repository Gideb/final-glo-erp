<section id="demo">

    <div class="demo-video" id="video-container">

        <img src="../images/glo-products/thumbnail.jpg" alt="Video Thumbnail" class="thumbnail">

        <div class="play-button"></div>
        <iframe
            id="videoframe"
            src=""
            title="Glo-Erp YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen>
        </iframe>
    </div>
</section>

